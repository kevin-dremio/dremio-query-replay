# Dremio Source Switcher

Dremio Source Switcher is a python-based utility for Dremio Enterprise. 
It enables a user to switch the name of the datasource that a set of VDSs in a Dremio environment get their data from.
The assumption is that the schema/folder hierarchy of the physical data sets in the from-datasource matches the hierarchy of the physical data sets in the to-datasource. The tool will check this on a per-VDS basis, so if there are some physical data sets present in the from-datasource that are not presentin the to-datasource then any VDSs referencing the from-datasource will not get updated and instead the failed VDS will be logged for manual intervention.

Running in a docker container
To run in a container, first build an image by navigating to the dremio-source-switcher folder on the command line and running:
docker build -t <image name> .

docker run --rm deanedremio/switcher --url http://192.168.0.21:9047/ --user dremio --password dremio123 --from-source switchertest --to-source switchertest2 --report-only