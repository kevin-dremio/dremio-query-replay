#!/usr/bin/python
import requests
import copy
import sys
import time
import gzip
import argparse
import json
import getpass
import logging
import pandas as pd
from QueryReplayerConfig import QueryReplayerConfig
from DremioUserThread import DremioUserThread

TEST_ID = int(time.time())
pd.set_option('mode.chained_assignment', None)

def main():
    logging.basicConfig(format="%(levelname)s:%(asctime)s:%(message)s", level=logging.INFO)
    fh = logging.FileHandler('dremio-query-replayer.log')
    fh.setLevel(logging.INFO)
    fh.setFormatter(logging.Formatter("%(levelname)s:%(asctime)s:%(message)s"))
    logging.getLogger().addHandler(fh)

    # open queries.json and filter out unwanted records
    logging.info('Importing queries')
    if input_queries[-3:] == '.gz':
        infile = gzip.open(input_queries, "rt")
    else:
        if sys.version_info.major > 2:
            f_open = lambda filename: open(filename, "r", encoding='utf-8')
        else:
            f_open = lambda filename: open(filename, "r")

        infile = f_open(input_queries)
        #infile = open(input_queries, "r", encoding="utf8")
    try:
        dfs = []
        data = [json.loads(line) for line in infile]
        for item in data:
            # Filter out non-select queries and prepare statements here
            if ('queryText' in item and "select " in item['queryText'].lower() and
                "create table " not in item['queryText'].lower() and
                "create or replace " not in item['queryText'].lower()) and \
                    ('queryType' in item and "PREPARE_INTERNAL" not in item['queryType'] and
                     "UI_INTERNAL_PREVIEW" not in item['queryType']) and \
                    ('requestType' in item and "CREATE_PREPARE" not in item['requestType']):
                try:
                    dataf = pd.DataFrame(item)[['start', 'username','queryText', 'outcome', 'requestType', 'queryType']]
                except Exception as e:
                    dataf = pd.DataFrame(item, index=[0])[['start', 'username','queryText', 'outcome', 'requestType', 'queryType']]
                dfs.append(dataf)
        queries_df = pd.concat(dfs, sort=False)
        queries_df['startDT'] = pd.to_datetime(queries_df['start'], unit='ms')
    except Exception as e:
        logging.error(e)

    if config_mode:
        config = QueryReplayerConfig(None)
        config_json = config.generate_config_json(queries_df)
        with open(output_config, 'w') as outfile:
            json.dump(config_json, outfile, default=str, indent=4)
        logging.info('Config Creation Completed')
    else:
        config = QueryReplayerConfig(input_config)
        obtain_password(config, password)
        if not config.target_verify_ssl:
            requests.packages.urllib3.disable_warnings(requests.packages.urllib3.exceptions.InsecureRequestWarning)
        # filter queries even further to only those we are interested in
        logging.info("Filtering queries based on configuration options")
        queries_df = queries_df[queries_df['queryType'].isin(config.in_list_query_types)]
        queries_df = queries_df[queries_df['requestType'].isin(config.in_list_request_types)]
        queries_df = queries_df[queries_df['outcome'].isin(config.in_list_outcomes)]
        queries_df = queries_df[queries_df['start'] >= config.time_from]
        queries_df = queries_df[queries_df['start'] <= config.time_to]
        #filter query text based on the exclude filter regex list
        for filter_item in config.query_text_exclude_filter_regex_list:
            queries_df = queries_df[~queries_df['queryText'].str.contains(filter_item)]

        # spawn a user thread for every user we want to run
        user_threads = list()
        distinct_users_in_queries = queries_df["username"].unique()
        for user_dict in config.in_list_users:
            if user_dict['username'] in distinct_users_in_queries:
                t = DremioUserThread(TEST_ID, user_dict['username'], user_dict['offsetSecs'], config, queries_df[queries_df['username'] == user_dict['username']], len(user_threads))
                user_threads.append(t)
                logging.info("Thread {} started for simulated user {}".format(len(user_threads)-1, user_dict['username']))
                t.start()
            else:
                logging.info('User {} has no queries in selected time frame, not logging in'.format(user_dict['username']))
        # wait for each thread to finish
        for index, thread in enumerate(user_threads):
            thread.join()
            logging.info("Thread {} done for simulated user {}".format(index, thread._username))
        logging.info("Query Replayer Complete")


def obtain_password(config, password):
    # Try to get the password from the parameters first
    if password:
        config.target_password = password
    # Then check if one is present in the configuration file, else ask for password
    elif config.target_password is None or config.target_password == "":
        config.target_password = getpass.getpass("Enter password:")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Script replay queries from queries.json in Dremio')
    parser.add_argument('--input-queries', type=str, help='queries.json file containing queries to replay', required=True)
    parser.add_argument('--config-mode', help='Run Query Replayer in config mode to generate config file', action='store_true')
    parser.add_argument('--output-config', type=str, help='Output config file to generate, only applicable to config mode', required=False)
    parser.add_argument('--password', type=str, help='Dremio user password', required=False)
    parser.add_argument('--input-config', type=str, help='Config file used to configure Query Replayer in execution mode', required=False)

    args = parser.parse_args()
    input_queries = args.input_queries
    config_mode = args.config_mode
    output_config = args.output_config
    password = args.password
    input_config = args.input_config

    if config_mode and not output_config:
        sys.exit('Value for --output-config must be specified when using --config-mode')

    main()
