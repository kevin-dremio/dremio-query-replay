########
# Copyright (C) 2019-2021 Dremio Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########
import threading
import time
import json
import logging
import requests
import pandas
import pyodbc
import sys

new_line = '\n'


class DremioQueryThread(threading.Thread):
    # Dremio user thread that will issue queries to Dremio
    _query = None
    _host = None
    _port = 31010
    _odbc_driver = 'Dremio ODBC Driver 64-bit'
    _admin_username = None
    _admin_password = None
    _impersonating_username = None
    _connection = None

    def __init__(self, *args):
        super(DremioQueryThread, self).__init__(group=None, target=None, name=None)
        self.args = args
        self._query = args[0]
        self._connection = args[1]
        return

    def run(self):
        cursor = None
        try:
            cursor = self._connection.cursor()
            cursor.execute(self._query)
            row = cursor.fetchone()
            while row:
                row = cursor.fetchone()
        except Exception as e:
            logging.info("Error processing query: ".format(e))
        except:
            pass
        finally:
            if cursor:
                cursor.close()