########
# Copyright (C) 2019-2021 Dremio Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########
import json
import logging
import sys
import fnmatch, re
from datetime import datetime
import time
from pytz import timezone

class QueryReplayerConfig:
	# Config json code
	replayer_conf_json = None
	# Target Dremio Environment definition
	target_endpoint = None
	target_verify_ssl = False
	target_username = None
	target_password = None
	target_odbc_driver = 'Dremio ODBC Driver 64-bit'
	target_num_executors = 0
	target_test_description = None
	# DCS placeholders
	target_dcs = False
	target_dcs_org_id = None
	target_dcs_project_id = None
	# Processing
	replay_speed = 1.0
	in_list_query_types = []
	in_list_request_types = []
	in_list_outcomes = []
	in_list_users = []
	total_users = 0
	time_from = None
	time_to = None
	query_text_exclude_filter_regex_list = []

	def __init__(self):
		return

	def __init__(self, input_config_file):
		if input_config_file:
			# Read configuration file
			if sys.version_info.major > 2:
				f_open = lambda filename: open(filename, "r", encoding='utf-8')
			else:
				f_open = lambda filename: open(filename, "r")

			f = f_open(input_config_file)

			self.replayer_conf_json = json.load(f)['query_replayer']
			f.close()
			for element in self.replayer_conf_json:
				if 'target' in element:
					self._process_target(element)
				elif 'options' in element:
					self._process_options(element)
		return

	def _process_target(self, json_conf):
		for item in json_conf['target']:
			if 'dremio_host' in item:
				self.target_endpoint = item['dremio_host']
			elif 'username' in item:
				self.target_username = item['username']
			elif 'password' in item:
				self.target_password = item['password']
			elif 'odbc_driver' in item:
				self.target_odbc_driver = item['odbc_driver']
			elif 'verify_ssl' in item:
				self.target_verify_ssl = self._bool(item, 'verify_ssl')
			elif 'num_executors' in item:
				self.target_num_executors = self._bool(item, 'num_executors')
			elif 'test_description' in item:
				self.target_test_description = item['test_description']
			elif 'is_dcs' in item:
				self.target_dcs = self._bool(item, 'is_dcs')
			elif 'dcs_org_id' in item:
				self.target_dcs_org_id = item['dcs_org_id']
			elif 'dcs_project_id' in item:
				self.target_dcs_project_id = item['dcs_project_id']

	def _process_options(self, json_conf):
		for item in json_conf['options']:
			if 'dry_run' in item:
				self.dry_run = self._bool(item, 'dry_run')
			elif 'replay_speed' in item:
				replay_speed = self._float(item, 'replay_speed')
				self.replay_speed = replay_speed if replay_speed and replay_speed > 0.0 else 1.0
			elif 'queryTypes' in item:
				self._process_query_types(item)
			elif 'requestTypes' in item:
				self._process_request_types(item)
			elif 'outcomes' in item:
				self._process_outcomes(item)
			elif 'users' in item:
				self._process_users(item)
			elif 'query_start_timespan' in item:
				self._process_query_start_timespan(item)
			elif 'query_text_exclude_filter_regex_list' in item:
				self.query_text_exclude_filter_regex_list = self._array(item, 'query_text_exclude_filter_regex_list')
				#for filter_item in filter_list:
				#	self.query_text_exclude_filter_regex_list.append(self._compile_pattern(filter_item))

	def _process_query_types(self, json_conf):
		for query_type_dict in json_conf['queryTypes']:
			for query_type in query_type_dict.keys():
				if 'process' == query_type_dict.get(query_type):
					self.in_list_query_types.append(query_type)

	def _process_request_types(self, json_conf):
		for request_type_dict in json_conf['requestTypes']:
			for request_type in request_type_dict.keys():
				if 'process' == request_type_dict.get(request_type):
					self.in_list_request_types.append(request_type)

	def _process_outcomes(self, json_conf):
		for outcomes_dict in json_conf['outcomes']:
			for outcome in outcomes_dict.keys():
				if 'process' == outcomes_dict.get(outcome):
					self.in_list_outcomes.append(outcome)

	def _process_users(self, json_conf):
		for users_dict in json_conf['users']:
			if 'process' == users_dict.get('mode'):
				self.in_list_users.append(users_dict)
		self.total_users = len(self.in_list_users)

	def _process_query_start_timespan(self, json_conf):
		for times_dict in json_conf['query_start_timespan']:
			for q_time in times_dict.keys():
				if sys.version_info.major > 2:
					localized_timestamp = timezone('UTC').localize(datetime.strptime(times_dict.get(q_time), '%Y-%m-%d %H:%M:%S.%f')).timestamp() * 1000
				else:
					localized_timestamp = time.mktime(timezone('UTC').localize(datetime.strptime(times_dict.get(q_time), '%Y-%m-%d %H:%M:%S.%f')).timetuple()) * 1000
				if 'time_from' == q_time:
					self.time_from = localized_timestamp
				if 'time_to' == q_time:
					self.time_to = localized_timestamp

	def generate_config_json(self, queries_df):
		queryReplayerDict = {'query_replayer': []}
		queryReplayerConfig = queryReplayerDict['query_replayer']
		target = {'target': [{'dremio_host':'localhost'},
							{'username': 'DREMIO_ADMIN_USERNAME_HERE'},
							{'password': 'DREMIO_ADMIN_PWD'},
							{'odbc_driver': 'Dremio ODBC Driver 64-bit'},
							{'verify_ssl': 'False'},
							{'num_executors': 4},
							{'test_description': 'load test local environment'}]}
		optionsDict = {'options': []}
		options = optionsDict['options']
		rtLabels = queries_df["requestType"].unique()
		qtLabels = queries_df["queryType"].unique()
		oLabels = queries_df["outcome"].unique()
		uLabels = queries_df["username"].unique()
		earliestQueryStart = queries_df["startDT"].min()
		latestQueryStart = queries_df["startDT"].max()

		replaySpeed = {'replay_speed': 1.0}
		requestTypes = {'requestTypes': [{rtLabel:'process'} for rtLabel in rtLabels]}
		queryTypes = {'queryTypes': [{qtLabel: 'process'} for qtLabel in qtLabels]}
		outcomes = {'outcomes': [{oLabel:'process'} for oLabel in oLabels]}
		usernames = {'users': [{'username': uLabel, 'mode': 'process', 'offsetSecs': 0} for uLabel in uLabels]}
		timespan = {'query_start_timespan' :[{'time_from': earliestQueryStart, 'time_to': latestQueryStart}]}
		queryTextExcludeFilter = {'query_text_exclude_filter_regex_list' : []}
		options.append(replaySpeed)
		options.append(requestTypes)
		options.append(queryTypes)
		options.append(outcomes)
		options.append(usernames)
		options.append(timespan)
		options.append(queryTextExcludeFilter)
		queryReplayerConfig.append(target)
		queryReplayerConfig.append(optionsDict)
		return queryReplayerDict

	def _bool(self, conf, param_name):
		if (param_name in conf):
			try:
				return eval(conf[param_name].title())
			except NameError:
				logging.fatal("Invalid boolean value for parameter " + param_name)
		else:
			return None

	def _float(self, conf, param_name):
		if (param_name in conf):
			try:
				return float(conf[param_name])
			except:
				logging.fatal("Invalid float value for parameter " + param_name)
		else:
			return None

	def _str(self, conf, param_name):
		if (param_name in conf and not conf[param_name] == ""):
			return conf[param_name]
		return None

	def _array(self, conf, param_name):
		if (param_name in conf):
			try:
				return conf[param_name]
			except:
				logging.fatal("Invalid array value for parameter " + param_name)
		else:
			return None

	def _compile_pattern(self, pattern):
		if pattern is None:
			return None
		return re.compile(fnmatch.translate(pattern))