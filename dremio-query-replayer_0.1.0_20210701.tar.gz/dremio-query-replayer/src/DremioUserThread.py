########
# Copyright (C) 2019-2021 Dremio Corporation
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
########
import threading
import time
import json
import logging
import requests
import sys
import pyodbc
from DremioQueryThread import DremioQueryThread
new_line = '\n'


class DremioUserThread(threading.Thread):
    # Dremio user thread that will issue queries to Dremio
    _user_offset = 0
    _config = None
    _username = None
    _user_queries = None
    _test_start_ms_since_epoch = None
    _auth_string = None
    _query_counter = 0
    _test_id = 0
    _total_num_users = 1
    _thread_id = 0

    def login(self, url, user, password, simulated_user, tls_verify):
        login_path = '/apiv2/login'
        logging.info("Logging in as {} to simulate user {}".format(user, simulated_user))
        login_data = {"userName": user, "password": password}
        response = requests.post(url + login_path, json=login_data, verify=tls_verify, timeout=30)
        if response.status_code != 200:
            sys.exit('Login failure, Status code : {}'.format(response.status_code))
        else:
            logging.info("Login successful")
            j = json.loads(response.text)
            return '_dremio' + j['token']

    # Returns Job ID or None
    def submit_sql(self, url, auth_string, sql, tls_verify, context=None):
        job = requests.post(url + "/api/v3/sql", headers={'Authorization': auth_string}, verify=tls_verify,
                            json={"sql": sql, "context": context})
        if job is not None and job.status_code != 200:
            logging.error('Query failure, Status code : {}'.format(job.status_code))
            return None
        return job.json()["id"]

    def __init__(self, *args):
        super(DremioUserThread, self).__init__(group=None, target=None, name=None)
        self.args = args
        self._test_id = args[0]
        self._username = args[1]
        self._user_offset_ms = args[2] * 1000
        self._config = args[3]
        self._test_start_ms_since_epoch = self._config.time_from
        self._user_queries = args[4]
        self._thread_id = args[5]
        self._user_queries['queryOffset'] = ((self._user_queries['start'] - self._test_start_ms_since_epoch) / self._config.replay_speed) + self._user_offset_ms
        #self._auth_string = self.login(self._config.target_endpoint, self._config.target_username, self._config.target_password, self._username, self._config.target_verify_ssl)
        return

    def run(self):
        current_time_ms = time.time() * 1000
        query_threads = []
        dremio_connection = pyodbc.connect(
            "Driver={};ConnectionType=Direct;HOST={};PORT={};AuthenticationType=Plain;UID={};PWD={}".format(
                self._config.target_odbc_driver, self._config.target_endpoint, 31010, self._config.target_username, self._config.target_password), autocommit=True)
        while not self._user_queries.empty:
            current_offset = int((time.time() * 1000) - current_time_ms)
            current_queries = self._user_queries[self._user_queries['queryOffset'] <= current_offset]
            for query in current_queries['queryText']:
                test_id_prefix = "--Q" + self._username + '-' + str(self._thread_id) + '-' + str(self._query_counter) + " --Test-" + str(self._test_id)
                query_header_comments = test_id_prefix + \
                                        "|ReplaySpeed-" + str(self._config.replay_speed) + \
                                        "|NumExecs-" + str(self._config.target_num_executors) + \
                                        "|NumOfUsers-" + str(self._config.total_users) + \
                                        "|User-" + str(self._username) + \
                                        "|UserQId-" + str(self._query_counter) + \
                                        "|OffsetSecs-" + str(int(self._user_offset_ms/1000)) + \
                                        "|Host-" + self._config.target_endpoint + \
                                        "|TestDesc-" + self._config.target_test_description if self._config.target_test_description else ''
                query = query_header_comments + new_line + query
                logging.info("Thread " + str(self._thread_id) + ": " + self._username + ": " + str(current_offset) + ": " + query)
                t = DremioQueryThread(query, dremio_connection)
                t.start()
                query_threads.append(t)
                #self.submit_sql(self._config.target_endpoint, self._auth_string, query, self._config.target_verify_ssl)
                self._query_counter += 1
            self._user_queries = self._user_queries[self._user_queries['queryOffset'] > current_offset]
            time.sleep(0.2)

        for index, thread in enumerate(query_threads):
            thread.join()
        if dremio_connection:
            dremio_connection.close()